// 공통 상수 / 유틸 — index.html, admin.html 둘 다 사용
const TYPES = {
  release:  { label: '발매',       color: '#ff6f91' },
  preorder: { label: '예약판매',   color: '#6c7bff' },
  lottery:  { label: '추첨·응모',  color: '#a46bff' },
  popup:    { label: '팝업스토어', color: '#ff9f1c' },
  restock:  { label: '재입고',     color: '#2bb486' },
  etc:      { label: '기타',       color: '#8a94a6' },
};
const SHOP_KINDS = { online: '온라인', offline: '오프라인', both: '온·오프라인' };
const WEEK = ['일', '월', '화', '수', '목', '금', '토'];

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function safeUrl(u) {
  u = String(u || '').trim();
  return /^https?:\/\//i.test(u) ? u : '';
}
function pad(n) { return String(n).padStart(2, '0'); }
function ymd(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function parseYmd(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
function todayStr() { return ymd(new Date()); }
function fmtDate(s) {
  if (!s) return '';
  const d = parseYmd(s);
  return `${d.getMonth() + 1}.${d.getDate()} (${WEEK[d.getDay()]})`;
}
function fmtRange(ev) {
  const end = ev.end && ev.end !== ev.start ? ` ~ ${fmtDate(ev.end)}` : '';
  const y = ev.start ? parseYmd(ev.start).getFullYear() + '. ' : '';
  return `${y}${fmtDate(ev.start)}${end}${ev.time ? ' · ' + esc(ev.time) : ''}`;
}
function evEnd(ev) { return ev.end && ev.end >= ev.start ? ev.end : ev.start; }
function uid(prefix) { return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function fmtPrice(p) {
  if (p === '' || p == null) return '';
  const n = Number(String(p).replace(/[^\d.]/g, ''));
  return isNaN(n) || String(p).match(/[^\d,.\s원]/) ? esc(p) : n.toLocaleString('ko-KR') + '원';
}
function normalize(data) {
  data = data || {};
  return {
    siteTitle: data.siteTitle || '굿즈 발매 캘린더',
    updatedAt: data.updatedAt || '',
    shops: Array.isArray(data.shops) ? data.shops : [],
    events: Array.isArray(data.events) ? data.events : [],
  };
}
// UTF-8 안전 base64 (GitHub API용)
function b64encode(str) { return btoa(unescape(encodeURIComponent(str))); }
function b64decode(b64) { return decodeURIComponent(escape(atob(b64.replace(/\s/g, '')))); }
